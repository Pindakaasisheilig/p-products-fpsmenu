--[[
 _       _____ 
| |     / ____|
| |    | (___
| |     \___ \
| |____ ____) |
|______|_____/

]]
                                 
                                 
fx_version 'cerulean'
game 'gta5'

version '1.0.0'
author 'Anto Orza#6115'
description 'LS FPS Menu (https://orzafamily.com/)'
repository 'https://github.com/LS-Robert/LS_MENU_FPS'

shared_script 'config.lua'

client_script 'client.lua'
