Config = {}

Config.framework = "qb" -- "qb" or "esx"